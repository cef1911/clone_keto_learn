# keto_learn
A ground-up library of data science, machine learning, graph analytics, deep learning, etc......


Inspired by:

- Grus, Data Science from Scratch
- Trask, Grokking Deep Learning
- Miller & Ranum, Problem Solving with Algorithms and Data Structures using Python
