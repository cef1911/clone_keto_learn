"""
Functions that perform various matrix decompositions"""


def singular_value_decomposition():

    pass

def non_negative_matrix_factorization():

    pass


def principle_components_analysis():

    pass