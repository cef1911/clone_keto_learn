"""
Basic Tensor Calculations and Operations:

The basis for these calculation is the python list. So, this is only for insight and education, not performance.
"""